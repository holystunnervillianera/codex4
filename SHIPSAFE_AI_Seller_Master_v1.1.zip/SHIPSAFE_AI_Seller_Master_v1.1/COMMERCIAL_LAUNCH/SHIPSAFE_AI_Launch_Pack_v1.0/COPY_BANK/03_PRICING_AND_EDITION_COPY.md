# SHIPSAFE AI Pricing and Edition Copy

## SHIPSAFE Solo

Founding price: US$39

Standard price: US$59

Buyer: A founder, learner, operator, or independent builder launching their own applications.

Rights: Use for projects owned and operated by the purchaser. No client-service use, resale, redistribution, sublicensing, or template sharing.

Contains: Finished operating manual, quick start, agent guardrails, project-control templates, testing and security checks, checkpoint and rollback procedures, readiness scorecard, capstone assets, and bonus quick tools.

## SHIPSAFE Commercial

Founding price: US$129

Standard price: US$179

Buyer: A freelancer, consultant, studio, or agency applying the system inside paid client work.

Rights: Use internally across client engagements and deliver completed reports or adapted outputs to clients. The underlying files, templates, and system may not be resold, redistributed, sublicensed, or offered as a competing template product.

Contains: Everything in Solo, plus editable premium source documents, client intake, audit-report assets, acceptance templates, and commercial project-use rights.
