# SHIPSAFE AI Seven-Day Launch Campaign

## Saturday, June 13 - Category creation: working is not ready

Goal: Introduce the invisible-risk category and publish the product without sounding like another AI template launch.

Your AI-built app working is not proof that it is ready to launch.

A generated application can load, accept input, and produce a clean demo while still:
- returning mocked data when the real integration fails
- allowing one user to request another user’s records
- shipping private configuration inside the browser bundle
- suppressing errors until every failure looks like success
- changing a working feature during an unrelated fix
- leaving no compatible rollback path for the database

The dangerous failures are not always the ones that crash. They are the ones that survive the demonstration.

I built SHIPSAFE AI to give AI-assisted builders persistent agent guardrails, security and authorization tests, regression controls, recovery procedures, and a 68-control launch-readiness decision system.

The rule is simple: an agent’s statement that the task is complete is not evidence.

Changed files, commands, tests, security results, acceptance criteria, and a recovery point are evidence.

CTA: Run the free 12-point fast test or review SHIPSAFE AI.

Proof asset: Show the scorecard dashboard and one agent guardrail file.

## Sunday, June 14 - Protect the project before the first major agent session

Goal: Reach people preparing for the Google/Kaggle course and anyone starting a new AI-built app.

Before an AI coding agent writes the next feature, give the project five things:

1. PROJECT_CONTEXT.md - what the product is, who it serves, and how the system works.
2. SCOPE_LOCK.md - what is in scope, out of scope, and forbidden without approval.
3. PROTECTED_FILES.md - the files and behaviors that must not be casually replaced.
4. ACCEPTANCE_CRITERIA.md - the evidence required before a task can be called complete.
5. A known-good checkpoint - the exact state you can return to when the “small fix” becomes a rewrite.

“Be careful” is not a control system. Persistent boundaries are.

CTA: Use the free setup list; the complete files are inside SHIPSAFE AI.

Proof asset: Share a redacted view of the five-file project-control layer.

## Monday, June 15 - Course day one: capstone boundaries

Goal: Intercept active course attention with a genuinely useful setup protocol.

Starting an AI-agent capstone today? Decide this before you build:

- the one user outcome the demo must prove
- what the agent may change without asking
- which files, features, and data paths are protected
- what counts as a real integration rather than a mock
- which tests must pass before the next task begins
- how you will restore the last working version

A capstone becomes easier when the scope is smaller and the evidence is stronger.

Do not use the final day to discover that the agent built a convincing interface around an unverified backend.

CTA: Use the Capstone Planner and Submission Checklist inside SHIPSAFE AI.

Proof asset: Show one completed example criterion, not product screenshots only.

## Tuesday, June 16 - False success

Goal: Make the buyer recognize a failure pattern they cannot solve with a generic prompt.

Four ways an AI coding agent can make a broken application look functional:

1. Catch the exception and return an empty response.
2. Replace the failed API call with static sample data.
3. Remove the validation causing the test to fail.
4. Display a success state before the durable operation completes.

The interface works. The product does not.

A proper release check forces the system to reveal failure, prove the real integration, preserve validation, and verify durable state after the action.

CTA: Use the Failure Mode Tests and Release Evidence Packet.

Proof asset: A before/after example of fake success versus verified failure.

## Wednesday, June 17 - Authorization and data boundaries

Goal: Connect launch risk directly to user trust without making unsupported security guarantees.

Authentication answers: “Who are you?”
Authorization answers: “Are you allowed to do this to this record?”

An AI-built app can have a polished login page and still fail the second question.

Before launch, test with two ordinary accounts:
- Can User A request User B’s record by changing an ID?
- Can User A update or delete it?
- Can a normal user call an admin endpoint directly?
- Can a private file be guessed or opened with another account?
- Does suspension or deletion invalidate the old session?

Do not test permissions only from the developer account.

CTA: Use the 12-case Authorization Test Matrix.

Proof asset: Show the matrix columns: actor, action, expected, actual, evidence.

## Thursday, June 18 - Rollback before repair

Goal: Reach builders currently experiencing agent-caused regressions.

Before asking an AI coding agent to “fix everything,” create a recovery boundary.

Record:
- the current branch and commit
- the last known-good tag
- uncommitted changes
- current environment configuration
- migration state
- the command that verifies core behavior
- the exact files the next task may change

Then isolate the fix.

A code rollback is not enough when the database, storage, or external configuration changed too. Recovery must restore a compatible system, not merely an older folder.

CTA: Use the Checkpoint Protocol and Recovery Runbook.

Proof asset: Demonstrate the included checkpoint script on a harmless sample repository.

## Friday, June 19 - Submission and launch evidence

Goal: Convert course participants and builders preparing a public release.

Before submitting or publishing an AI-built app, ask for evidence - not confidence.

Your release packet should contain:
- every changed file
- commands run
- test output
- authorization results
- secret and dependency checks
- acceptance-criteria results
- known limitations
- rollback evidence
- the final go/no-go decision

A polished demo explains what the product does. A release packet proves what was actually verified.

CTA: Complete the SHIPSAFE Launch Readiness Scorecard before submission.

Proof asset: Show a blurred/fictional release evidence packet and readiness decision.

## Saturday, June 20 - From capstone or prototype to product

Goal: Transition from event urgency into the evergreen offer.

The capstone is finished. The product work begins.

Before turning a prototype into a portfolio asset, client deliverable, or micro-SaaS:
- remove mock and privileged development paths
- verify clean-account onboarding
- test authorization across two users
- separate production configuration
- define monitoring and cost ceilings
- prove rollback
- record known limitations
- make an explicit launch decision

SHIPSAFE AI turns those tasks into one repeatable operating system rather than another round of improvised prompts.

CTA: Founding launch pricing closes; standard pricing begins after the campaign.

Proof asset: Solo vs Commercial comparison and the complete file inventory.
