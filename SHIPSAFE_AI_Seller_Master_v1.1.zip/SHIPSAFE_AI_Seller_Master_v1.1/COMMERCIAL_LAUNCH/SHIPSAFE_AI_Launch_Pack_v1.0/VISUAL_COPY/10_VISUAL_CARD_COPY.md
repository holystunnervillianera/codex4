# SHIPSAFE AI Visual Card Copy

## Cards

### Category card

YOUR AI-BUILT APP WORKING IS NOT PROOF THAT IT IS READY TO LAUNCH.

Subline: Test the invisible paths before real users do.

### False success card

THE INTERFACE WORKS. THE PRODUCT DOES NOT.

Mock data. Silent fallbacks. Suppressed failures. Premature success states.

### Evidence card

“DONE” IS A CLAIM. EVIDENCE IS A RELEASE DECISION.

Changed files + commands + tests + security results + acceptance criteria + rollback.

### Authorization card

A LOGIN PAGE DOES NOT PROTECT ANOTHER USER’S DATA.

Test two ordinary accounts. Try cross-user read, update, delete, admin, and file access.

### Recovery card

A GIT ROLLBACK MAY NOT RESTORE YOUR DATABASE.

Recover a compatible system, not only an older code folder.

### Scorecard card

68 CONTROLS. 10 CONTROL AREAS. ONE GO/NO-GO DECISION.

Unknown scores zero until evidence exists.

### Product stack card

CONSTRAIN. INSPECT. TEST. SECURE. RECOVER. PROVE. LAUNCH.

The SHIPSAFE Verification Loop.

### Solo card

SHIPSAFE SOLO

For builders launching their own AI-built projects. Founding price: US$39.

### Commercial card

SHIPSAFE COMMERCIAL

Client audit assets + editable source + commercial project-use rights. Founding price: US$129.

### Closing card

PRODUCTION READINESS IS NOT A VIBE.

It is a collection of verified controls.
