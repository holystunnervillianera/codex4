# SHIPSAFE AI FAQ and Objection Handling

## Frequently asked questions

### Is SHIPSAFE AI a security guarantee?

No. It is an engineering control and verification framework. It reduces avoidable uncertainty and exposes missing evidence, but it is not a penetration test, compliance certification, legal opinion, or guarantee against defects or attacks.

### Do I need to be a developer?

No. The Quick Start, scorecard, checklists, and agent files are designed to make technical verification legible to nontechnical builders. Some remediation work may still require qualified technical help.

### Which coding agents does it support?

The pack includes dedicated files for Claude Code, Codex-style AGENTS.md workflows, Gemini, and Cursor, plus universal guardrails that can be adapted to other agents.

### Does it scan my private code?

No. The product is delivered as local files and templates. Buyers decide what to share with their tools. The 12-point fast test and readiness scorecard can be completed without uploading source code to SHIPSAFE.

### Will it fix my application automatically?

No. It tells the builder and their coding agent what must be verified, what evidence is missing, where launch risk exists, and how to control, test, and recover the work.

### What is the difference between Solo and Commercial?

Solo is for projects owned and operated by the purchaser. Commercial adds client-use rights, editable premium source materials, and client audit assets for paid engagements.

### Can I resell the templates?

No. Neither licence permits resale, redistribution, sublicensing, white-labelling of the underlying system, or offering the files as a competing template product.

### Can I use Commercial for multiple clients?

Yes, inside paid client work, subject to the included licence. You may deliver completed reports and project-specific outputs, but not the reusable source system itself.

### Is this only useful during the Google/Kaggle course?

No. The course provides a timely acquisition angle. The controls are evergreen for any AI-built app, agent, micro-SaaS, internal tool, or client project.

### What happens after purchase?

The buyer downloads the edition they purchased, opens the Quick Start, installs the appropriate guardrail files, completes project context and scope controls, runs the readiness assessment, resolves failures, and records the go/no-go decision.

### Are updates included?

The purchase covers the version delivered. Do not promise lifetime updates or implementation support unless you intentionally add those terms later.

### Why is “Unknown” treated as zero in the scorecard?

Because an unverified control is not evidence of safety or correctness. The framework rewards proof, not assumption.

## Objection handling

### “My app already works.”

Working in one session proves only that one path produced an acceptable result once. It does not verify authorization, data isolation, failure behavior, secret handling, regression protection, recovery, or a clean-user journey.

### “My AI tool already tests its work.”

The same system that generated the implementation should not be the only authority deciding whether it is complete. SHIPSAFE requires independently reviewable evidence and explicit launch criteria.

### “I can ask ChatGPT for a checklist.”

A generated checklist is not a persistent operating system. SHIPSAFE connects agent boundaries, project scope, security tests, regression protection, recovery, evidence, scoring, and licensing into one reusable workflow.

### “I can use free security scanners.”

Automated scanners are useful but narrow. They do not confirm business logic, mock data, acceptance criteria, authorization journeys, agent scope, rollback readiness, or whether a failure was converted into fake success.

### “This sounds too technical.”

The product is specifically designed to translate technical launch risk into structured questions, pass/fail evidence, and a clear go/no-go decision.

### “I will deal with it after launch.”

After launch, every unresolved issue is exposed to real users, real data, public reputation, and production dependencies. The cheapest time to create a checkpoint and prove access boundaries is before release.

### “I only built a small MVP.”

Small scope lowers complexity; it does not eliminate authentication, data, credential, failure, billing, or recovery risk.
