# SHIPSAFE AI Launch Pack v1.0

Seller-only commercialisation system prepared 13 June 2026.

## Start here

1. Open `SHIPSAFE_AI_Commercial_Launch_Master.pdf`.
2. Use the files in `COPY_BANK` as clean copy-and-paste sources.
3. Keep the campaign timing separate from the evergreen product position.
4. Use `SELLER_OPERATIONS/11_LAUNCH_OPERATIONS_CHECKLIST.md` before publication.
5. Do not deliver this seller pack to Solo or Commercial customers.

## Core commercial structure

- SHIPSAFE Solo: US$39 founding / US$59 standard.
- SHIPSAFE Commercial: US$129 founding / US$179 standard.
- One-time purchase; no subscription, implementation, guaranteed security, or lifetime-update promise.

## Important

Complete product-name/trademark, consumer-law, privacy, tax, refund, and licence review before public commercial release.
