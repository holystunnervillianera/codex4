# SHIPSAFE AI Seller Master v1.1

Private seller source-of-truth package.

## PRODUCT_SOURCE
Contains the complete product source used to build the Solo and Commercial customer editions.

## COMMERCIAL_LAUNCH
Contains the 37-page commercial launch master, clean copy banks, structured JSON, visual copy, launch operations, sources, inventory, and checksums.

## Customer deliveries
Continue delivering the separately packaged Solo and Commercial ZIP archives. Do not deliver this seller master or the seller-only launch pack to customers.

## Commercial structure
- SHIPSAFE Solo: US$39 founding / US$59 standard.
- SHIPSAFE Commercial: US$129 founding / US$179 standard.
- One-time purchase; no subscription, implementation service, security guarantee, or lifetime-update promise.

Complete name/trademark and jurisdiction-specific legal review before public commercial release.
