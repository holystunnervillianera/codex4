# SHIPSAFE AI Market Timing and Sources

## Timing note

The June 13-20, 2026 campaign uses the Google/Kaggle course as a temporary acquisition angle. The permanent product positioning is evergreen launch assurance for AI-built applications.

## Sources

### Google and Kaggle AI Agents Intensive: Vibe Coding

https://blog.google/innovation-and-ai/technology/developers-tools/kaggle-genai-intensive-course-vibe-coding-june-2026/

Use: Official confirmation of the June 15-19, 2026 course, production-ready agent focus, capstone, and prior course reach.

### OpenAI - Codex for every role, tool, and workflow

https://openai.com/index/codex-for-every-role-tool-workflow/

Use: Official June 2026 market context: more than five million weekly users and fast growth among non-developers.

### Anthropic - Beyond permission prompts: making Claude Code more secure and autonomous

https://www.anthropic.com/engineering/claude-code-sandboxing

Use: Official explanation of filesystem/network isolation, permission fatigue, prompt injection, and bounded agent access.

### Anthropic - How we contain Claude across products

https://www.anthropic.com/engineering/how-we-contain-claude

Use: Official May 2026 discussion of unexpected agent behavior and containment.

### OpenAI Codex repository

https://github.com/openai/codex

Use: Official description of Codex CLI as a local coding agent and supported editor workflows.
