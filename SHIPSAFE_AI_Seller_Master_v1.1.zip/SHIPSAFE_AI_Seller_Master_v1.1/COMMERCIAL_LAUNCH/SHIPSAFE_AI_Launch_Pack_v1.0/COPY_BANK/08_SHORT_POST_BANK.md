# SHIPSAFE AI Short Post Bank

## Posts

1. An AI agent saying “done” is a completion claim. Test output, changed files, security results, and acceptance criteria are completion evidence.

2. A page loading proves rendering. It does not prove authorization, durable state, or a real integration.

3. The most dangerous AI coding failure may be a fallback that looks exactly like success.

4. Do not let the agent delete a failing test to make the test suite green.

5. Hide an admin button if you want. Protect the admin action on the server if you need security.

6. Your .env file can be private while your browser bundle still exposes the value.

7. A Git rollback does not automatically reverse a database migration.

8. Test your app with two ordinary accounts, not only one privileged developer account.

9. The smaller the capstone scope, the stronger the evidence you can collect.

10. “Make the app production-ready” is not an acceptance criterion.

11. Every high-risk task should begin with a known-good checkpoint and end with a changed-file report.

12. If failure returns empty data and a success message, the interface is lying on behalf of the system.

13. Unknown is not pass. In SHIPSAFE, an unverified control scores zero until evidence exists.

14. A coding agent should stop when requirements conflict. Inventing the missing decision is not autonomy; it is uncontrolled scope.

15. If you cannot restore the previous compatible state, you do not have a tested rollback plan.

16. Mock data is useful in development. Undisclosed mock data is dangerous in a launch decision.

17. Client-side validation improves experience. Server-side validation protects the system.

18. A security checklist without an owner, evidence, and a go/no-go decision becomes decoration.

19. The app can be technically impressive and still be operationally unlaunchable.

20. SHIPSAFE AI is not a security guarantee. It is the system that stops “we assumed” from being treated as “we verified.”

21. The correct time to document recovery is before the incident, not while the agent is still editing.

22. One vague fix request can cross authentication, database, UI, and infrastructure boundaries. Scope it before execution.

23. A clean demo is marketing evidence. A regression suite is engineering evidence.

24. The objective is not zero risk. It is visible risk, verified controls, and an informed launch decision.

25. Before launch, search the codebase for mock, demo, fixture, fallback, TODO, FIXME, hardcoded, and placeholder.

26. A completed task report should include what changed, what ran, what passed, what failed, and what remains unknown.

27. The agent should make the smallest viable change, not the most impressive rewrite.

28. Production readiness is not a vibe. It is a collection of verified controls.
